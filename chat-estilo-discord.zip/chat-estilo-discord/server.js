const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { WebSocketServer } = require('ws');
const Database = require('better-sqlite3');

const SECRET = process.env.SECRET || 'troque-este-segredo';
const PORT = process.env.PORT || 3000;
const db = new Database(process.env.DB || 'chat.db');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT UNIQUE, salt TEXT, hash TEXT);
CREATE TABLE IF NOT EXISTS servers(id INTEGER PRIMARY KEY, name TEXT);
CREATE TABLE IF NOT EXISTS channels(id INTEGER PRIMARY KEY, server_id INT, name TEXT);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY, channel_id INT, user TEXT, text TEXT, ts INT);
`);
const newServer = name => {
  const id = db.prepare('INSERT INTO servers(name) VALUES(?)').run(name).lastInsertRowid;
  db.prepare('INSERT INTO channels(server_id,name) VALUES(?,?)').run(id, 'geral');
};
if (!db.prepare('SELECT 1 FROM servers').get()) newServer('Comunidade');

const sign = n => n + '.' + crypto.createHmac('sha256', SECRET).update(n).digest('hex');
const verify = t => { const n = (t || '').split('.')[0]; return t === sign(n) ? n : null; };
const hash = (p, s) => crypto.scryptSync(p, s, 32).toString('hex');

const server = http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/api/auth') {
    let body = '';
    req.on('data', c => (body += c));
    req.on('end', () => {
      const send = (code, o) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
      let name, password;
      try { ({ name, password } = JSON.parse(body)); } catch { return send(400, { error: 'Pedido inválido.' }); }
      if (!/^\w{2,20}$/.test(name || '')) return send(400, { error: 'Nome: 2 a 20 letras, números ou _.' });
      if (typeof password !== 'string' || password.length < 6) return send(400, { error: 'A senha precisa ter 6+ caracteres.' });
      const u = db.prepare('SELECT * FROM users WHERE name=?').get(name);
      if (!u) {
        const salt = crypto.randomBytes(16).toString('hex');
        db.prepare('INSERT INTO users(name,salt,hash) VALUES(?,?,?)').run(name, salt, hash(password, salt));
      } else if (!crypto.timingSafeEqual(Buffer.from(u.hash), Buffer.from(hash(password, u.salt)))) {
        return send(401, { error: 'Senha incorreta.' });
      }
      send(200, { token: sign(name), name });
    });
    return;
  }
  fs.readFile(path.join(__dirname, 'public', 'index.html'), (e, d) => {
    res.writeHead(e ? 500 : 200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(d);
  });
});

const wss = new WebSocketServer({ server });
const snapshot = () => ({
  type: 'state',
  servers: db.prepare('SELECT * FROM servers').all(),
  channels: db.prepare('SELECT * FROM channels').all(),
});
const broadcast = m => wss.clients.forEach(c => c.readyState === 1 && c.send(JSON.stringify(m)));
const clean = s => String(s || '').trim().slice(0, 30);

wss.on('connection', (ws, req) => {
  const user = verify(new URL(req.url, 'http://x').searchParams.get('token'));
  if (!user) return ws.close(4001);
  ws.send(JSON.stringify(snapshot()));
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (m.type === 'history') {
      const messages = db.prepare('SELECT * FROM messages WHERE channel_id=? ORDER BY id DESC LIMIT 100').all(m.channel).reverse();
      ws.send(JSON.stringify({ type: 'history', channel: m.channel, messages }));
    } else if (m.type === 'msg' && typeof m.text === 'string' && m.text.trim()) {
      const text = m.text.trim().slice(0, 2000), ts = Date.now();
      const id = db.prepare('INSERT INTO messages(channel_id,user,text,ts) VALUES(?,?,?,?)').run(m.channel, user, text, ts).lastInsertRowid;
      broadcast({ type: 'msg', message: { id, channel_id: m.channel, user, text, ts } });
    } else if (m.type === 'server' && clean(m.name)) {
      newServer(clean(m.name)); broadcast(snapshot());
    } else if (m.type === 'channel' && clean(m.name)) {
      db.prepare('INSERT INTO channels(server_id,name) VALUES(?,?)').run(m.server, clean(m.name).toLowerCase().replace(/\s+/g, '-'));
      broadcast(snapshot());
    }
  });
});

server.listen(PORT, () => console.log('Rodando em http://localhost:' + PORT));
